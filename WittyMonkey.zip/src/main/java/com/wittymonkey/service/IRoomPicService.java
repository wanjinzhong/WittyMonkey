package com.wittymonkey.service;

public interface IRoomPicService {

}
