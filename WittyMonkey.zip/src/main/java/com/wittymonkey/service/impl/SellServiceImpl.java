package com.wittymonkey.service.impl;

import com.wittymonkey.service.ISellService;
import org.springframework.stereotype.Service;

@Service(value = "sellService")
public class SellServiceImpl implements ISellService {

}
