package com.wittymonkey.service.impl;

import com.wittymonkey.service.IRoomPicService;
import org.springframework.stereotype.Service;

@Service(value = "roomPicService")
public class RoomPicServiceImpl implements IRoomPicService {

}
