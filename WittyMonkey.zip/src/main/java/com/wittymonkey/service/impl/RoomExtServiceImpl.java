package com.wittymonkey.service.impl;

import com.wittymonkey.service.IRoomExtService;
import org.springframework.stereotype.Service;

@Service(value = "roomExtService")
public class RoomExtServiceImpl implements IRoomExtService {

}
