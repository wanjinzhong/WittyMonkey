package com.wittymonkey.service.impl;

import com.wittymonkey.service.ILogService;
import org.springframework.stereotype.Service;

@Service(value = "logService")
public class LogServiceImpl implements ILogService {

}
