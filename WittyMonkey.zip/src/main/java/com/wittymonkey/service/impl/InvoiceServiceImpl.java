package com.wittymonkey.service.impl;

import com.wittymonkey.service.IInvoiceService;
import org.springframework.stereotype.Service;

@Service(value = "invoiceService")
public class InvoiceServiceImpl implements IInvoiceService {

}
