package com.wittymonkey.service.impl;

import com.wittymonkey.service.INotifyFileService;
import org.springframework.stereotype.Service;

@Service(value = "NotifyFileService")
public class NotifyFileServiceImpl implements INotifyFileService {

}
