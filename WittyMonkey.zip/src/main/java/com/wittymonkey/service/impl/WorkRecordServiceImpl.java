package com.wittymonkey.service.impl;

import com.wittymonkey.service.IWorkRecordService;
import org.springframework.stereotype.Service;

@Service(value = "workRecordService")
public class WorkRecordServiceImpl implements IWorkRecordService {

}
