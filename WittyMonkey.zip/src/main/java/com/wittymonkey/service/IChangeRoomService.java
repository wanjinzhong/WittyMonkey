package com.wittymonkey.service;

import com.wittymonkey.entity.ChangeRoom;

public interface IChangeRoomService {

    void save(ChangeRoom changeRoom);
}
