package com.wittymonkey.service;

public interface ILogService {

}
