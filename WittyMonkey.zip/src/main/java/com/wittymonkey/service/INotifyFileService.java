package com.wittymonkey.service;

public interface INotifyFileService {

}
