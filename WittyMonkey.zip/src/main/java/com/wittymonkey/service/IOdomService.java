package com.wittymonkey.service;

/**
 * Created by neilw on 2017/4/22.
 */
public interface IOdomService {
    void newOdom(Integer hotelId);
}
