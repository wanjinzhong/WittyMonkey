package com.wittymonkey.dao;

import com.wittymonkey.entity.Invoice;

import java.io.Serializable;

public interface IInvoiceDao extends IGenericDao<Invoice, Serializable> {

}
