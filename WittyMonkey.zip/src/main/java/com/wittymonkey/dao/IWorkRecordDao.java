package com.wittymonkey.dao;

import com.wittymonkey.entity.WorkRecord;

import java.io.Serializable;

public interface IWorkRecordDao extends IGenericDao<WorkRecord, Serializable> {

}
