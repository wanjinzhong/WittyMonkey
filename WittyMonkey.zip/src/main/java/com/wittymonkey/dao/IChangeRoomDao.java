package com.wittymonkey.dao;

import com.wittymonkey.entity.ChangeRoom;

import java.io.Serializable;

public interface IChangeRoomDao extends IGenericDao<ChangeRoom, Serializable> {

}
