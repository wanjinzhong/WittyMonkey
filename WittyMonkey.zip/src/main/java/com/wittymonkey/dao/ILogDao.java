package com.wittymonkey.dao;

import com.wittymonkey.entity.Log;

import java.io.Serializable;

public interface ILogDao extends IGenericDao<Log, Serializable> {

}
