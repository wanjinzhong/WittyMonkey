package com.wittymonkey.dao;

import com.wittymonkey.entity.RoomPic;

import java.io.Serializable;

public interface IRoomPicDao extends IGenericDao<RoomPic, Serializable> {

}
