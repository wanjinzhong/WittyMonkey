package com.wittymonkey.dao;

import com.wittymonkey.entity.Odom;

import java.io.Serializable;

/**
 * Created by neilw on 2017/4/22.
 */
public interface IOdomDao extends IGenericDao<Odom, Serializable> {

}
