package com.wittymonkey.dao;

import com.wittymonkey.entity.NotifyFile;

import java.io.Serializable;

public interface INotifyFileDao extends IGenericDao<NotifyFile, Serializable> {

}
