package com.wittymonkey.dao;

import com.wittymonkey.entity.Sell;

import java.io.Serializable;

public interface ISellDao extends IGenericDao<Sell, Serializable> {

}
