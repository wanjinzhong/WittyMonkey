package com.wittymonkey.dao;

import com.wittymonkey.entity.RoomExt;

import java.io.Serializable;

public interface IRoomExtDao extends IGenericDao<RoomExt, Serializable> {

}
